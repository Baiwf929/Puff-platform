package demo;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class test {
    public static void main(String args[]){
        /*Date date = new Date(System.currentTimeMillis());
        Timestamp t = new Timestamp(System.currentTimeMillis());
        String k = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(t);
        System.out.println(date);
        System.out.println(k);
        Company c = CompanyDAO.getCompany(1);
        System.out.println(c.toString());
        User u = UserDAO.login("white","87654321");
        System.out.println(u.toString());*/
        List<Sale> sales = SaleDAO.getALLSales(17205889);
        for(Sale e:sales ){
            System.out.println(e.toString());
        }
        List<Item> items = ItemDAO.getALLItems("FPS");
        for(Item t:items ){
            System.out.println(t.toString());
        }
        Item sss = ItemDAO.getPreferenceItem("FPS");
        System.out.println(sss.toString());
        /*
        User u = UserDAO.login("white","87654321");
        boolean ads = PaymentDAO.PayFullPayment(u,2,328);
        System.out.println(ads);*/
    }

}
