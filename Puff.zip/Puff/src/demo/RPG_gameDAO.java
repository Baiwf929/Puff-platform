package demo;

import java.sql.*;



public class RPG_gameDAO{
	public static RPG_game game(int id) {
		Connection conn = null;
		
		try {
			conn = JDBCTool.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM RPG_game WHERE Item_id='"+id+"'");
            if(rs.next()) {
				int i = rs.getInt("Item_id");
            	String n = rs.getString("game_theme");
				RPG_game r = new RPG_game(i,n);
				System.out.println(n + " and " + i);
				return r;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return null;
	}

}
	

