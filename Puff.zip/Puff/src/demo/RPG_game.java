package demo;

public class RPG_game {
    private int Item_id;
    private String game_theme;

    public RPG_game(int item_id, String game_theme) {
        Item_id = item_id;
        this.game_theme = game_theme;
    }

    public int getItem_id() {
        return Item_id;
    }

    public void setItem_id(int item_id) {
        Item_id = item_id;
    }

    public String getGame_theme() {
        return game_theme;
    }

    public void setGame_theme(String game_theme) {
        this.game_theme = game_theme;
    }

    @Override
    public String toString() {
        return  "game_theme='" + game_theme + '\'';
    }
}
