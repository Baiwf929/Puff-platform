package demo;
import java.sql.*;

public class CompanyDAO {
    public static Company getCompany(int C_id){
        Connection conn = null;

        try {
            conn = JDBCTool.getConnection();
            PreparedStatement st = conn.prepareStatement("SELECT * FROM Company WHERE C_id="+C_id);
            ResultSet rs = st.executeQuery();
            if(rs.next()) {
                int cid = rs.getInt("C_id");
                String Cname = rs.getString("C_name");
                String Caddress = rs.getString("C_address");
                String Ctel = rs.getString("C_tel");
                String license = rs.getString("License");
                Company c = new Company(cid,Cname,Caddress,Ctel,license);
                return c;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
        }

        return null;
    }
}
