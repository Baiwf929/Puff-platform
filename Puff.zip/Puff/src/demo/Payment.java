package demo;

public class Payment {
    private int User_id;
    private int S_id;
    private String condition;
    private float price;
    private String PayDate;

    public Payment(int user_id, int s_id, String condition, float price, String payDate) {
        User_id = user_id;
        S_id = s_id;
        this.condition = condition;
        this.price = price;
        PayDate = payDate;
    }

    public int getUser_id() {
        return User_id;
    }

    public void setUser_id(int user_id) {
        User_id = user_id;
    }

    public int getS_id() {
        return S_id;
    }

    public void setS_id(int s_id) {
        S_id = s_id;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getPayDate() {
        return PayDate;
    }

    public void setPayDate(String payDate) {
        PayDate = payDate;
    }

    @Override
    public String toString() {
        return "Payment{" +
                "User_id=" + User_id +
                ", S_id=" + S_id +
                ", condition='" + condition + '\'' +
                ", price=" + price +
                ", PayDate=" + PayDate +
                '}';
    }
}
