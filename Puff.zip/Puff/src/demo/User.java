package demo;

public class User {
    private int user_id;
    private String User_name;
    private String password;
    private String User_tel;
    private String preference;
    private String Registration_date;
    private float balance;

    public User(int user_id, String user_name, String password, String user_tel, String preference, String registration_date, float balance) {
        this.user_id = user_id;
        User_name = user_name;
        this.password = password;
        User_tel = user_tel;
        this.preference = preference;
        Registration_date = registration_date;
        this.balance = balance;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getUser_name() {
        return User_name;
    }

    public void setUser_name(String user_name) {
        User_name = user_name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUser_tel() {
        return User_tel;
    }

    public void setUser_tel(String user_tel) {
        User_tel = user_tel;
    }

    public String getPreference() {
        return preference;
    }

    public void setPreference(String preference) {
        this.preference = preference;
    }

    public String getRegistration_date() {
        return Registration_date;
    }

    public void setRegistration_date(String registration_date) {
        Registration_date = registration_date;
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "user{" +
                "user_id=" + user_id +
                ", User_name='" + User_name + '\'' +
                ", password='" + password + '\'' +
                ", User_tel=" + User_tel +
                ", preference='" + preference + '\'' +
                ", Registration_date=" + Registration_date +
                ", balance=" + balance +
                '}';
    }
}
