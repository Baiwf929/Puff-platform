package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCTool {

    public static final String URL = "jdbc:mysql://localhost:3306/puff?&useSSL=false&serverTimezone=UTC";
    public static final String USER = "root";
    public static final String PASSWORD = "baiwf929";

    public static Connection getConnection(String url, String username, String password) {
        Connection conn = null;
        String driver="com.mysql.jdbc.Driver";
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url,username,password);
            if(!conn.isClosed()){
                System.out.println("success");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return conn;
    }


    public static Connection getConnection() {
        return JDBCTool.getConnection(URL, USER, PASSWORD);
    }

}