package demo;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {
    public static Payment createPayment(int User_id, int S_id){
        Connection conn = null;
        PreparedStatement pst = null;


        try {
            String k = "waiting";
            Timestamp time = new Timestamp(System.currentTimeMillis());
            String paytime = new SimpleDateFormat("yyyy-MM-dd").format(time);
            float PRICE = SaleDAO.getPrice(S_id);
            String createpay="insert into payment VALUES (?,?,?,?,?)";
            conn = JDBCTool.getConnection();
            pst=conn.prepareStatement(createpay);
            pst.setInt(1, User_id);
            pst.setInt(2,S_id);
            pst.setString(3, k);
            pst.setFloat(4, PRICE);
            pst.setString(5, paytime);

            if(pst.executeUpdate()>0){
                Payment pa = new Payment(User_id,S_id,k,PRICE,paytime);

                System.out.print("success");
                return pa;

            }else{

                System.out.print("fail");
                return null;

            }
        }catch(SQLException e){
            e.printStackTrace();
        } finally{
            try {
                pst.close();
                conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
        return null;
    }

    public static void deletePayment(int S_id){
        Connection conn = null;
        PreparedStatement pst = null;
        PreparedStatement pst1 = null;

        try {
            String deletepay="delete from Payment where S_id = "+S_id;
            String updateSale="update Sales set S_condition = 'canceled' where S_id = "+S_id;
            conn = JDBCTool.getConnection();
            pst=conn.prepareStatement(deletepay);
            pst.executeUpdate();
            pst1=conn.prepareStatement(updateSale);
            pst1.executeUpdate();

        }catch(SQLException e){
            e.printStackTrace();
        } finally{
            try {
                pst.close();
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }
    }

    public static List<Payment> getALLPayment(int user_id){
        List<Payment> pays = new ArrayList<Payment>();
        try {
            Connection conn = JDBCTool.getConnection();
            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery("SELECT * FROM Payment where User_id = "+ user_id);

            while(rs.next()) {

                int uid = rs.getInt("User_id");
                int sid = rs.getInt("S_id");
                String codition = rs.getString("condition");
                float price = rs.getFloat("price");
                String pdate = rs.getString("PayDate");


                Payment pay = new Payment(uid,sid,codition,price,pdate);

                pays.add(pay);
            }

            rs.close();
            st.close();
            conn.close();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return pays;

    }


    public static boolean PayFullPayment(User u,int S_id, float price) {
        Connection conn = null;
        PreparedStatement pst = null;
        PreparedStatement pst2 = null;
        int User_id = u.getUser_id();
        float U_balance = u.getBalance();
        if (U_balance < price) {    //not enough balance
            return false;
        } else {
            try {
                float remain = U_balance - price;
                Timestamp time = new Timestamp(System.currentTimeMillis());
                String paytime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(time);
                String upsql = "update Payment SET `condition` =?, PayDate = ? where User_id=? and S_id =?";
                //condition needs to be quoted in `` to avoid overlapping keyword with MYSQL
                String deduction = "update Users set balance =? where User_id =?";
                conn = JDBCTool.getConnection();
                pst = conn.prepareStatement(upsql);
                pst.setString(1, "success");
                pst.setString(2, paytime);
                pst.setInt(3, User_id);
                pst.setInt(4, S_id);
                pst.executeUpdate();
                //after changing the state of Payment we need to deduct the balance of User
                pst2 = conn.prepareStatement(deduction);
                pst2.setFloat(1,remain);
                pst2.setInt(2,User_id);
                pst2.executeUpdate();
                return true;

            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    pst.close();
                    conn.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }


            }
        }
        return false;

    }
    
    public static Payment getPayment(int uid, int sid) {
    	Connection conn = null;

        try {
            conn = JDBCTool.getConnection();
            PreparedStatement st = conn.prepareStatement("SELECT * FROM Payment WHERE User_id ="+uid+" and S_Id = "+sid);
            ResultSet rs = st.executeQuery();
            if(rs.next()) {

                int userid = rs.getInt("User_id");
                int saleid = rs.getInt("S_id");
                String condition = rs.getString("condition");
                float price = rs.getFloat("price");
                String paydate = rs.getString("PayDate");
                
                Payment p = new Payment(userid,saleid,condition,price,paydate);

                return p;

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
        }

        return null;
    }
    }

