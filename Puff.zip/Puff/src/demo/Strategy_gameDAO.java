package demo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class Strategy_gameDAO{
	public static Strategy_game game(int id) {
		Connection conn = null;
		
		try {
			conn = JDBCTool.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM Strategy_game WHERE Item_id='"+id+"'");
            if(rs.next()) {
				int i = rs.getInt("Item_id");
            	String n = rs.getString("game_sort");
				Strategy_game r = new Strategy_game(i,n);
				System.out.println(n + " and " + i);
				return r;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return null;
	}

}
	

