package demo;

public class Strategy_game {
    private int Item_id;
    private String game_sort;

    public Strategy_game(int item_id, String game_sort) {
        Item_id = item_id;
        this.game_sort = game_sort;
    }

    public int getItem_id() {
        return Item_id;
    }

    public void setItem_id(int item_id) {
        Item_id = item_id;
    }

    public String getGame_sort() {
        return game_sort;
    }

    public void setGame_sort(String game_sort) {
        this.game_sort = game_sort;
    }

    @Override
    public String toString() {
        return "game_sort='" + game_sort + '\'';
    }
}
