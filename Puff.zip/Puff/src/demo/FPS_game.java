package demo;

public class FPS_game {
    private int Item_id;
    private int tickrate;

    public FPS_game(int item_id, int tickrate) {
        Item_id = item_id;
        this.tickrate = tickrate;
    }

    public int getItem_id() {
        return Item_id;
    }

    public void setItem_id(int item_id) {
        Item_id = item_id;
    }

    public int getTickrate() {
        return tickrate;
    }

    public void setTickrate(int tickrate) {
        this.tickrate = tickrate;
    }

    @Override
    public String toString() {
        return  "tickrate=" + tickrate;
    }
}
