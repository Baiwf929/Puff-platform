package demo;

public class Sport_game {
    private int Item_id;
    private String Sport_type;

    public Sport_game(int item_id, String sport_type) {
        Item_id = item_id;
        Sport_type = sport_type;
    }

    public int getItem_id() {
        return Item_id;
    }

    public void setItem_id(int item_id) {
        Item_id = item_id;
    }

    public String getSport_type() {
        return Sport_type;
    }

    public void setSport_type(String sport_type) {
        Sport_type = sport_type;
    }

    @Override
    public String toString() {
        return "Sport_type='" + Sport_type + '\'';
    }
}
