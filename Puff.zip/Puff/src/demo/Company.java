package demo;

public class Company {
    private int C_id;
    private String C_name;
    private String C_address;
    private String C_tel;
    private String License;

    public Company(int c_id, String c_name, String c_address, String c_tel, String license) {
        C_id = c_id;
        C_name = c_name;
        C_address = c_address;
        C_tel = c_tel;
        License = license;
    }

    public int getC_id() {
        return C_id;
    }

    public void setC_id(int c_id) {
        C_id = c_id;
    }

    public String getC_name() {
        return C_name;
    }

    public void setC_name(String c_name) {
        C_name = c_name;
    }

    public String getC_address() {
        return C_address;
    }

    public void setC_address(String c_address) {
        C_address = c_address;
    }

    public String getC_tel() {
        return C_tel;
    }

    public void setC_tel(String c_tel) {
        C_tel = c_tel;
    }

    public String getLicense() {
        return License;
    }

    public void setLicense(String license) {
        License = license;
    }

    @Override
    public String toString() {
        return "Company{" +
                "C_name='" + C_name + '\'' +
                ", C_address='" + C_address + '\'' +
                ", C_tel=" + C_tel +
                ", License='" + License + '\'' +
                '}';
    }
}
