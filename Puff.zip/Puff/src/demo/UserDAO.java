package demo;
import java.sql.*;
import java.text.SimpleDateFormat;


public class UserDAO{
	
	public static void UpdateUserInfo(int User_id,String User_name,String password,String User_tel, String preference ) {
		Connection conn = null;
        PreparedStatement pst = null;
	
		
			try {

				String upsql="update users set User_name=?,password=?,User_tel=?,preference=? where User_id=?";
				conn = JDBCTool.getConnection();
				pst=conn.prepareStatement(upsql);
				pst.setString(1, User_name);
				pst.setString(2, password);
				pst.setString(3,User_tel);
				pst.setString(4, preference);
				pst.setInt(5, User_id);
			    //pst.executeUpdate();
			    
			    if(pst.executeUpdate()>0){

					System.out.print("���³ɹ�");

				}else{

					System.out.print("����ʧ��");

				}  
		}catch(SQLException e){
            e.printStackTrace();
        } finally{
           try {
        	   	pst.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         
           
        }

	}

	public static User login(String User_name, String password) {
		Connection conn = null;

		try {
			conn = JDBCTool.getConnection();
			PreparedStatement st = conn.prepareStatement("SELECT * FROM Users WHERE User_name='"+User_name+"' AND password='"+password+"'");
			ResultSet rs = st.executeQuery();
			System.out.println("SELECT * FROM Users WHERE User_name='"+User_name+"' AND password='"+password+"'");
			if(rs.next()) {
				int ui = rs.getInt("user_id");
				String un = rs.getString("User_name");
				String p = rs.getString("password");
				String ut = rs.getString("User_tel");
				String pr = rs.getString("preference");
				String rd = rs.getString("Registration_date");
				int ba = rs.getInt("balance");
				User u = new User(ui,un,p,ut,pr,rd,ba);
				return u;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}

		return null;
	}


	public static void Deposit(int User_id, float amount) throws SQLException{
		Connection conn = null;
		PreparedStatement stmt = null;


		try {
			conn = JDBCTool.getConnection();
			String upsql="update users set balance= balance + ? where User_id= ?";
			stmt=conn.prepareStatement(upsql);
			stmt.setFloat(1, amount);
			stmt.setInt(2, User_id);
			int result =stmt.executeUpdate();
			if(result>0){
				System.out.print("success");
			}else{
				System.out.print("fail");
			}
		}catch(SQLException e){
			e.printStackTrace();
		} finally{
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		}

	}

	public static void register(String username,String password, String tel, String prefer) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		Date date = new Date(System.currentTimeMillis());
		String k = new SimpleDateFormat("yyyy-MM-dd").format(date);
		try {
			con = JDBCTool.getConnection();
			String sql = "insert into users(User_id, User_name, password, User_tel, preference, Registration_date, balance) values(null, ?, ?, ?, ?, ?, 0)";
			stmt = con.prepareStatement(sql);
			stmt.setString(1, username);
			stmt.setString(2, password);
			stmt.setString(3, tel);
			stmt.setString(4, prefer);
			stmt.setString(5, k);
			int result =stmt.executeUpdate();// ����ֵ�����յ�Ӱ�������
			System.out.println(result+" changed, Register Success"+username);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			stmt.close();
			con.close();
		}
	}
}
