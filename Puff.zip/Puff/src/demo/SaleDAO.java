package demo;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class SaleDAO {
    public static Sale createSale(int User_id, int Item_id){
        Connection conn = null;
        PreparedStatement pst = null;
        PreparedStatement pst1 = null;

        try {
            String k = "to be paid";
            Timestamp time = new Timestamp(System.currentTimeMillis());
            String saletime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(time);
            String createsale="insert into sales VALUES (?,?,?,?,?)";
            conn = JDBCTool.getConnection();
            pst=conn.prepareStatement(createsale);
            pst.setString(1, null);
            pst.setInt(2,User_id);
            pst.setInt(3, Item_id);
            pst.setString(4, saletime);
            pst.setString(5, k);

            if(pst.executeUpdate()>0){
                String getSale = "Select S_id from Sales where User_id = '" + User_id + "' and S_time = '"+saletime +"'";
                pst1 = conn.prepareStatement(getSale);
                ResultSet rs = pst1.executeQuery();
                int sid = 0;
                while(rs.next()){
                    sid = rs.getInt("S_id");
                }
                Sale sa = new Sale(sid,User_id,Item_id,saletime,k);

                System.out.print("success");
                return sa;

            }else{

                System.out.print("fail");
                return null;

            }
        }catch(SQLException e){
            e.printStackTrace();
        } finally{
            try {
                pst.close();
                pst1.close();
                conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
    return null;
    }

    public static List<Sale> getALLSales(int user_id){
        List<Sale> sales = new ArrayList<Sale>();
        try {
            Connection conn = JDBCTool.getConnection();
            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery("SELECT * FROM Sales where User_id = '"+ user_id +"'");

            while(rs.next()) {

                int sid = rs.getInt("S_id");
                int uid = rs.getInt("User_id");
                int iid = rs.getInt("Item_id");
                String stime = rs.getString("S_time");
                String scondition = rs.getString("S_condition");


                Sale sale = new Sale(sid,uid,iid,stime,scondition);

                sales.add(sale);
            }

            rs.close();
            st.close();
            conn.close();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return sales;

    }

    public static float getPrice(int S_id){
        float PRICE = 0;
        int iid1 = 0;
        try {
            Connection connn = JDBCTool.getConnection();
            Statement st = connn.createStatement();

            ResultSet rs1 = st.executeQuery("SELECT Item_id FROM Sales where S_id = "+ S_id);
            while(rs1.next()) {
                iid1 = rs1.getInt("Item_id");
            }
            ResultSet rs2 = st.executeQuery("SELECT price FROM Items where Item_id = "+ iid1);
            while(rs2.next()) {
                PRICE = rs2.getFloat("price");
            }

            rs1.close();
            rs2.close();
            st.close();
            connn.close();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return PRICE;
    }
    
    public static void setCondition(int S_id){
        Connection conn = null;
        PreparedStatement pst = null;
        try {
            String updateSale="update Sales set S_condition = 'success' where S_id = "+S_id;
            conn = JDBCTool.getConnection();
            pst=conn.prepareStatement(updateSale);
            pst.executeUpdate();


        }catch(SQLException e){
            e.printStackTrace();
        } finally{
            try {
                pst.close();
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }
    }
}
