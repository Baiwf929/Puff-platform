package demo;

public class Sale {
    private int S_id;
    private int User_id;
    private int Item_id;
    private String S_time;
    private String S_condition;

    public Sale(int s_id, int user_id, int item_id, String s_time, String s_condition) {
        S_id = s_id;
        User_id = user_id;
        Item_id = item_id;
        S_time = s_time;
        S_condition = s_condition;
    }

    public int getS_id() {
        return S_id;
    }

    public void setS_id(int s_id) {
        S_id = s_id;
    }

    public int getUser_id() {
        return User_id;
    }

    public void setUser_id(int user_id) {
        User_id = user_id;
    }

    public int getItem_id() {
        return Item_id;
    }

    public void setItem_id(int item_id) {
        Item_id = item_id;
    }

    public String getS_time() {
        return S_time;
    }

    public void setS_time(String s_time) {
        S_time = s_time;
    }

    public String getS_condition() {
        return S_condition;
    }

    public void setS_condition(String s_condition) {
        S_condition = s_condition;
    }

    @Override
    public String toString() {
        return "Sale{" +
                "S_id=" + S_id +
                ", User_id=" + User_id +
                ", Item_id=" + Item_id +
                ", S_time='" + S_time + '\'' +
                ", S_condition='" + S_condition + '\'' +
                '}';
    }
}
