package demo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {
    public static List<Item> getALLItems(String label){
        List<Item> items = new ArrayList<Item>();
        try {
            Connection conn = JDBCTool.getConnection();
            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery("SELECT * FROM Items where label = '"+ label + "'");

            while(rs.next()) {

                int Itemid = rs.getInt("Item_id");
                String Gname = rs.getString("Gname");
                float price = rs.getFloat("price");
                String release = rs.getString("release");
                float lowest_price = rs.getFloat("lowest_price");
                String pic = rs.getString("Item_pic");
                int cid = rs.getInt("C_id");
                String ilabel = rs.getString("label");
                String Description = rs.getString("Description");


                Item item = new Item(Itemid, Gname, price, release, lowest_price, pic,cid,ilabel,Description);

                items.add(item);
            }

            rs.close();
            st.close();
            conn.close();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return items;


}
    
    
    public static List<Item> Search(String text){
        List<Item> items = new ArrayList<Item>();
        try {
            Connection conn = JDBCTool.getConnection();
            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery("SELECT * FROM Items where Gname LIKE '%"+ text + "%'");

            while(rs.next()) {

                int Itemid = rs.getInt("Item_id");
                String Gname = rs.getString("Gname");
                float price = rs.getFloat("price");
                String release = rs.getString("release");
                float lowest_price = rs.getFloat("lowest_price");
                String pic = rs.getString("Item_pic");
                int cid = rs.getInt("C_id");
                String ilabel = rs.getString("label");
                String Description = rs.getString("Description");


                Item item = new Item(Itemid, Gname, price, release, lowest_price, pic,cid,ilabel,Description);

                items.add(item);
            }

            rs.close();
            st.close();
            conn.close();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return items;


}
    
    
    public static List<Item> Order(String label, String column){
        List<Item> items = new ArrayList<Item>();
        try {
            Connection conn = JDBCTool.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = null;
            if(column.equals("release")) {
            	rs = st.executeQuery("SELECT * FROM Items where label = '"+ label + "' ORDER BY `"+column+"` "+"DESC");
            }
            else {
            	rs = st.executeQuery("SELECT * FROM Items where label = '"+ label + "' ORDER BY `"+column+"`");
            }
            /*if(d==1) {
            	rs = st.executeQuery("SELECT * FROM Items where label = '"+ label + "' ORDER BY '"+column+"'");
            }
            else {
            	rs = st.executeQuery("SELECT * FROM Items where label = '"+ label + "' ORDER BY '"+column+"' DESC");
            }
            */

            while(rs.next()) {

                int Itemid = rs.getInt("Item_id");
                String Gname = rs.getString("Gname");
                float price = rs.getFloat("price");
                String release = rs.getString("release");
                float lowest_price = rs.getFloat("lowest_price");
                String pic = rs.getString("Item_pic");
                int cid = rs.getInt("C_id");
                String ilabel = rs.getString("label");
                String Description = rs.getString("Description");


                Item item = new Item(Itemid, Gname, price, release, lowest_price, pic,cid,ilabel,Description);

                items.add(item);
            }

            rs.close();
            st.close();
            conn.close();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return items;


}
    
    
    public static Item getItem(int Item_id){
        Connection conn = null;

        try {
            conn = JDBCTool.getConnection();
            PreparedStatement st = conn.prepareStatement("SELECT * FROM Items WHERE Item_id="+Item_id);
            ResultSet rs = st.executeQuery();
            if(rs.next()) {

                int Itemid = rs.getInt("Item_id");
                String Gname = rs.getString("Gname");
                float price = rs.getFloat("price");
                String release = rs.getString("release");
                float lowest_price = rs.getFloat("lowest_price");
                String pic = rs.getString("Item_pic");
                int cid = rs.getInt("C_id");
                String ilabel = rs.getString("label");
                String Description = rs.getString("Description");


                Item item = new Item(Itemid, Gname, price, release, lowest_price, pic,cid,ilabel,Description);

                return item;

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
        }

        return null;
    }

    public static Item getPreferenceItem(String label){
        Connection conn = null;

        try {
            conn = JDBCTool.getConnection();
            PreparedStatement st = conn.prepareStatement("SELECT * FROM Items where label = '" + label +"'"+ " ORDER BY RAND() LIMIT 1 ");
            ResultSet rs = st.executeQuery();
            if(rs.next()) {

                int Itemid = rs.getInt("Item_id");
                String Gname = rs.getString("Gname");
                float price = rs.getFloat("price");
                String release = rs.getString("release");
                float lowest_price = rs.getFloat("lowest_price");
                String pic = rs.getString("Item_pic");
                int cid = rs.getInt("C_id");
                String ilabel = rs.getString("label");
                String Description = rs.getString("Description");


                Item item = new Item(Itemid, Gname, price, release, lowest_price, pic,cid,ilabel,Description);

                return item;

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            if(conn!=null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
        }

        return null;
    }
}
