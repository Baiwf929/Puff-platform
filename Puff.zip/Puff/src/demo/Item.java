package demo;

public class Item {
    private int Item_id;
    private String Gname;
    private float price;
    private String release;
    private float lowest_price;
    private String Item_pic;
    private int C_id;
    private String label;
    private String Description;

    public Item(int item_id, String gname, float price, String release, float lowest_price, String item_pic, int c_id, String label, String description) {
        Item_id = item_id;
        Gname = gname;
        this.price = price;
        this.release = release;
        this.lowest_price = lowest_price;
        Item_pic = item_pic;
        C_id = c_id;
        this.label = label;
        Description = description;
    }

    public int getItem_id() {
        return Item_id;
    }

    public void setItem_id(int item_id) {
        Item_id = item_id;
    }

    public String getGname() {
        return Gname;
    }

    public void setGname(String gname) {
        Gname = gname;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public float getLowest_price() {
        return lowest_price;
    }

    public void setLowest_price(float lowest_price) {
        this.lowest_price = lowest_price;
    }

    public String getItem_pic() {
        return Item_pic;
    }

    public void setItem_pic(String item_pic) {
        Item_pic = item_pic;
    }

    public int getC_id() {
        return C_id;
    }

    public void setC_id(int c_id) {
        C_id = c_id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String toStringBasic() {                           //used in home.jsp and Sport.jsp etc to show basic game info
        return "Item{" +
                "Gname='" + Gname + '\'' +
                ", price=" + price +
                ", label='" + label + '\'' +
                '}';
    }

    @Override
    public String toString() {                      //used to display more detailed info in game.jsp
        return "Item{" +
                "Gname='" + Gname + '\'' +
                ", price=" + price +
                ", release=" + release +
                ", lowest_price=" + lowest_price +
                ", label='" + label + '\'' +
                ", Description='" + Description + '\'' +
                '}';
    }
}
